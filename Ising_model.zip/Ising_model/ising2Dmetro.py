import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import colormaps as cmaps
import time
import cv2
import os

from scipy import constants
from functools import wraps
from numba import njit
from matplotlib.font_manager import FontProperties
from matplotlib.patches import Patch
from matplotlib.colors import ListedColormap

def timeit(func):
    @wraps(func)
    #args e kwargs permettono a una funzione "wrapper" di accettare qualsiasi tipo di input senza sapere in anticipo quanti 
    #o quali parametri riceverà la funzione originale
    def _func(*args, **kwargs):
        ti = time.time()
        res = func(*args, **kwargs)
        tf = time.time()
        dt = tf - ti
        print(f"Wall time: {dt:.6f} s")
        return res
    return _func

def plot(datiX, datiY1, datiY2, titoloPrincipale, titoloX, titoloY, titoloLegenda1, titoloLegenda2, nome_output):
    # FONT
    # Definizione esplicita delle proprietà del font Times New Roman
    times_font = FontProperties(family='Times New Roman', style='normal')
    times_dict = {'fontname': 'Times New Roman'}
    # Configurazione globale di backup
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif']
    plt.rcParams['mathtext.fontset'] = 'stix'
    # Mantiene lo stile Times anche per formule matematiche

    # print("Y1 min:", np.min(datiY1))
    # print("Y1 max:", np.max(datiY1))
    # #print("Y1 primi valori:", datiY1[:10])
    # print("Y2 min:", np.min(datiY2))
    # print("Y2 max:", np.max(datiY2))

    # Creazione della figura fig con dimensioni (width, height), ax sono gli assi
    fig, ax = plt.subplots(figsize=(7, 5), dpi=300)

    # SCATTERPLOT
    # Grafico a dispersione con punti adattati allo stile dell'istogramma. s è un parametro di size
    ax.plot(datiX, datiY1, color="#B22222", alpha=0.8, linewidth=0.8, label=titoloLegenda1)
    #ax.scatter(datiX, datiY1, color="#B22222", alpha=0.8, edgecolors="#B22222", linewidths=0.0, s=3, label=titoloLegenda1)

    # SCATTERPLOT 2 (Seconda serie di dati aggiunta, es. Energia Potenziale)
    ax.plot(datiX, datiY2, color="#00416D", alpha=0.8, linewidth=0.8, label=titoloLegenda2)
    #ax.scatter(datiX, datiY2, color="#00416D", alpha=0.8, edgecolors="#00416D", linewidths=0.0, s=3, label=titoloLegenda2)

    # TITOLI
    # Etichette degli assi e titolo interno
    ax.set_xlabel(titoloX, fontsize=16, labelpad=8)
    ax.set_ylabel(titoloY, fontsize=16, labelpad=8)
    # Posizione del titolo (centrato in alto)
    ax.text(0.5, 0.95, titoloPrincipale, 
            transform=ax.transAxes, fontsize=13,
            verticalalignment='top', horizontalalignment='center')
    # Aumenta il limite Y massimo del 25% per creare spazio bianco in alto ( *1.25)
    # interval_max = max(ax.get_ylim()[1], ax.get_xlim()[1])
    # interval_min = min(ax.get_ylim()[0], ax.get_xlim()[0])
    # ax.set_ylim(interval_min, interval_max * 1.25)
    # ax.set_xlim(interval_min, interval_max * 1.25)
    # #stessa scala
    # ax.set_aspect('equal', adjustable='box') 

    #AGGIUNTA DINAMICA
    all_y = np.concatenate([datiY1, datiY2])
    ymin, ymax = np.min(all_y), np.max(all_y)
    yrange = ymax - ymin
    # Crea dinamicamente uno spazio bianco extra in alto (~35%) per titolo e legenda
    ax.set_ylim(ymin - 0.05 * yrange, ymax + 0.35 * yrange)
    ax.set_xlim(np.min(datiX) - 0.02 * (np.max(datiX) - np.min(datiX)), 
                np.max(datiX) + 0.02 * (np.max(datiX) - np.min(datiX)))

    # LEGENDA
    # Impostazione della legenda (senza bordo/frame e centrata sotto il titolo)
    ax.legend(frameon=False, fontsize=11, loc='upper center', bbox_to_anchor=(0.5, 0.88))

    # TICK
    # Gestione dei tick (max 6 punti per asse, tacche rivolte all'interno)
    ax.xaxis.set_major_locator(ticker.MaxNLocator(nbins=7))
    ax.yaxis.set_major_locator(ticker.MaxNLocator(nbins=7))
    # RIMOZIONE tick in alto e a destra (top=False, right=False)
    ax.tick_params(axis='both', which='major', labelsize=12, direction='in', top=False, right=False)
    # Forzatura del font sui numeri degli assi (tick labels)
    fig.canvas.draw()  # Genera i tick prima di modificarne le proprietà
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontfamily('serif')
        label.set_fontname('STIXGeneral')

    # SALVATAGGIO
    # Layout e salvataggio
    plt.tight_layout()
    # Salvataggio in formato JPEG e risoluzione
    plt.savefig(f'{nome_output}.jpg', format='jpeg', dpi=300)
    #plt.show()
    plt.close(fig)

def snapshot(final_lattice, T, step, nome_output):
    # FONT
    # Definizione esplicita delle proprietà del font Times New Roman
    times_font = FontProperties(family='Times New Roman', style='normal')
    # Configurazione globale di backup
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif']
    plt.rcParams['mathtext.fontset'] = 'stix'
    # Mantiene lo stile Times anche per formule matematiche


    #plt.register_cmap(name='viridis', cmap=cmaps.viridis)
    #plt.set_cmap(cmaps.viridis)

    #img=mpimg.imread('stinkbug.png')
    #lum_img = np.flipud(img[:,:,0])
    #imgplot = plt.pcolormesh(lum_img)

    # Generazione dello snapshot
    #Alternativamente posso decidere io i colori per l'oggetto cmap
    #cmap = ListedColormap(['#00416D', '#B22222']) 
    fig, ax = plt.subplots(figsize=(5, 5), dpi=300) #figure and axes
    ax.imshow(final_lattice, cmap='viridis',
                interpolation='nearest')
    ax.set_title(f"Spin configuration for $T = {T:.2f}$",
                fontsize=12)

    # LEGENDA
    cmap = plt.get_cmap('viridis')
    legenda = [
        Patch(facecolor=cmap(1.0), label=r"$s_i = +1$"),
        Patch(facecolor=cmap(0.0), label=r"$s_i = -1$")
    ]
    ax.legend(handles=legenda,
            loc='upper center',
            bbox_to_anchor=(0.5, -0.08),
            ncol=2,
            frameon=False,
            fontsize=12)
    
    # SALVATAGGIO
    plt.tight_layout()
    plt.savefig(f"{nome_output}.jpg",
                format='jpeg', dpi=300, bbox_inches='tight')
    #plt.show()
    plt.close(fig)

def crea_video_da_immagini(lista_immagini, fps, video_output):
    if not lista_immagini:
        print("La lista delle immagini è vuota!")
        return

    # Leggi la prima immagine per ricavare larghezza e altezza (risoluzione)
    frame_esempio = cv2.imread(lista_immagini[0])
    if frame_esempio is None:
        print(f"Errore nella lettura del file: {lista_immagini[0]}")
        res = None
        return
        
    altezza, larghezza, canali = frame_esempio.shape

    # Imposta il codec video per il formato .mp4 ('mp4v' è ampiamente compatibile)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    
    # Inizializza l'oggetto VideoWriter
    video_writer = cv2.VideoWriter(video_output, fourcc, fps, (larghezza, altezza))

    print(f"Sto generando il video ({video_output})...")
    
    for nome_file in lista_immagini:
        frame = cv2.imread(nome_file)
        if frame is not None:
            video_writer.write(frame)  # Scrive il frame nel video
        else:
            print(f"Attenzione: impossibile leggere {nome_file}, saltato.")

    # Rilascia e chiude il file video
    video_writer.release()
    print("Video completato e salvato con successo!")

    # Facoltativo: elimina i file JPG temporanei dopo aver fatto il video
    for nome_file in lista_immagini:
        if os.path.exists(nome_file):
            os.remove(nome_file)

#(3)
#@njit
def calculate_total_energy(lattice, L, J):
    """
    Calcola l'energia totale del sistema considerando i 
    vicini primi con condizioni al contorno periodiche (PBC).
    """
    energy = 0.0
    for i in range(L):
        for j in range(L):
            s = lattice[i, j]
            # Somma sui vicini di destra e in basso per evitare doppi conteggi
            neighbors = lattice[(i + 1) % L, j] + lattice[i, (j + 1) % L]
            #H_ising=-J*sum(s*S)
            energy += -J * s * neighbors
    return energy

def calculate_magnetization(lattice):
    """Calcola la magnetizzazione totale del reticolo."""

    #la magnetizzazione del reticolo è semplicemente lo spin totale
    return np.sum(lattice)

#(2)
#@njit
def metropolis_step_random(lattice, L, T, J):
    """
    Esegue un intero passo Monte Carlo (MCS) tentando il flip 
    di N = L*L singoli spin scelti casualmente.
    """

    #Utilizzando una modalità di scambio casuale 
    N = L * L
    for _ in range(N):
        #La posizione del flip è casuale.
        i = np.random.randint(0, L)
        j = np.random.randint(0, L)
        #Il suo spin iniziale è salvato
        s = lattice[i, j]
        
        # Somma dei 4 vicini primi con PBC (su, giù, destra, sinistra).
        #L'operazione %L è cio che implementa le PBC: se i=L-1 e lo spin si 
        #trova al bordo, computare i+1/L risulta in 1 con resto 0. L'operazione %
        #restituisce il resto, che coincide con la posizone opposta nel reticolo.
        neighbors = (lattice[(i + 1) % L, j] + 
                     lattice[(i - 1) % L, j] + 
                     lattice[i, (j + 1) % L] + 
                     lattice[i, (j - 1) % L])

        #Calcoliamo le'energia totale di H=-Js*S per questo blocco di primi vicini, 
        #che sottraiamo con l'energia che si avrebbe nel blocco a seguito del flip.
        #delta_E=-(J*S*s_f-J*S*s_i)
        #Se s_f=-s e s_i=s E=2JSs
        #Se s e S hanno segni discordi il cambio è favorito
        delta_E = 2.0 * J * s * neighbors
        
        # Criterio di accettazione di Metropolis. Se la differenza in energia è 
        #negativa, per esempio lo spin era inizialmente -s e viene capovolto in +s,
        #lo spin sommario dei primi vicini S è negativo, indicando uun flip favorito,
        #che porta a minimizzare l'energia dell'interazione nel blocco.
        if delta_E <= 0.0:
            #Flip
            lattice[i, j] = -s
        else:
            #Se lo spin è sfavorito, comunque per Boltzmann si ha una probabilità 
            #che l'energia delta_E realizzi la configurazione. L'evento è casuale,
            #la funzione random.rand() di numpy genera un numero casuale fra
            #0.0 e 1.0 ed il nuovo if lo confronta con la probabilità P(E, T)
            if np.random.rand() < np.exp(-delta_E / T):
                lattice[i, j] = -s

def metropolis_step_ordered_horizontal(lattice, L, T, J):
    """
    Esegue un intero passo Monte Carlo (MCS) tentando il flip 
    di N = L*L singoli spin scelti casualmente.
    """

    #Utilizzando una modalità di scambio ordinata 
    #N = L * L
    for i in range(L):
        for j in range(L):
            #La posizione del flip è casuale.
            # i = np.random.randint(0, L)
            # j = np.random.randint(0, L)
            #Il suo spin iniziale è salvato
            s = lattice[i, j]
            
            # Somma dei 4 vicini primi con PBC (su, giù, destra, sinistra).
            #L'operazione %L è cio che implementa le PBC: se i=L-1 e lo spin si 
            #trova al bordo, computare i+1/L risulta in 1 con resto 0. L'operazione %
            #restituisce il resto, che coincide con la posizone opposta nel reticolo.
            neighbors = (lattice[(i + 1) % L, j] + 
                        lattice[(i - 1) % L, j] + 
                        lattice[i, (j + 1) % L] + 
                        lattice[i, (j - 1) % L])

            #Calcoliamo le'energia totale di H=-Js*S per questo blocco di primi vicini, 
            #che sottraiamo con l'energia che si avrebbe nel blocco a seguito del flip.
            #delta_E=-(J*S*s_f-J*S*s_i)
            #Se s_f=-s e s_i=s E=2JSs
            #Se s e S hanno segni discordi il cambio è favorito
            delta_E = 2.0 * J * s * neighbors
            
            # Criterio di accettazione di Metropolis. Se la differenza in energia è 
            #negativa, per esempio lo spin era inizialmente -s e viene capovolto in +s,
            #lo spin sommario dei primi vicini S è negativo, indicando uun flip favorito,
            #che porta a minimizzare l'energia dell'interazione nel blocco.
            if delta_E <= 0.0:
                #Flip
                lattice[i, j] = -s
            else:
                #Se lo spin è sfavorito, comunque per Boltzmann si ha una probabilità 
                #che l'energia delta_E realizzi la configurazione. L'evento è casuale,
                #la funzione random.rand() di numpy genera un numero casuale fra
                #0.0 e 1.0 ed il nuovo if lo confronta con la probabilità P(E, T)
                if np.random.rand() < np.exp(-delta_E / T):
                    lattice[i, j] = -s

#(1)
@timeit
def run_ising_simulation(L, T, J, nmcs, video):
    """
    Esegue la simulazione salvando l'andamento istantaneo 
    di energia e magnetizzazione per ogni passo Monte Carlo.
    """

    N = L * L
    #Inizializziamo il modello con una distribuzione casuale degli spin.
    #np.random.choice è una funzione che permette di estrarre campioni casuali
    #da un insieme di valori dati.
    #size(L, L) è una funzione di numpy specifica la forma dell'array 
    #risultante ed il tutto viene assegnato all'array lattice.
    seed = int.from_bytes(os.urandom(4), byteorder="big")
    np.random.seed(seed)
    print(f"Simulazione L={L}, T={T} -> Seed utilizzato: {seed}")
    lattice = np.random.choice([-1, 1], size=(L, L))
    #Se volessi la prima configurazione ordinata:
    #lattice = np.full((L, L), -1)

    #inizializza la matrice relativa all'energia media e la magnetizzazione
    #media per ogni step metropolis.
    energy_history = np.zeros(nmcs)
    magnetization_history = np.zeros(nmcs)

    # IMPOSTAZIONI VIDEO
    fps=8    
    target_frames = 200 #video di 25 secondi
    # Per evitare lo zero, risultante dal comando //, prendiamo 1
    intervallo_snapshot = max(1, nmcs // target_frames)  
    immagini_frame = []
  
    for step in range(nmcs):
        metropolis_step_random(lattice, L, T, J)
        #metropolis_step_ordered_horizontal(lattice, L, T, J)
        
        # Registrazione dei valori medi per particella (istantanei)
        E = calculate_total_energy(lattice, L, J)
        M = calculate_magnetization(lattice)
        
        energy_history[step] = E / N
        magnetization_history[step] = M / N

        if video:
            if step % intervallo_snapshot == 0:
                nome_file = f"frame_{step}.jpg"
                snapshot(lattice, T, step, nome_output=f"frame_{step}")
                immagini_frame.append(nome_file)

    # Check per il video:
    print("Tipo di lista_immagini:", type(immagini_frame))
    #print("Contenuto di lista_immagini[0]:", repr(immagini_frame[0]), "Tipo:", type(immagini_frame[0]))

    if video:
        crea_video_da_immagini(immagini_frame, fps, video_output=f"ising_L{L}_T{T}_J{J}.mp4")
    # (lista_immagini, fps, video_output)

    return energy_history, magnetization_history

def run_ising_simulation_videoT(L, T, J, nmcs, video):
    """
    Esegue la simulazione salvando l'andamento istantaneo 
    di energia e magnetizzazione per ogni passo Monte Carlo.
    """

    N = L * L
    #Inizializziamo il modello con una distribuzione casuale degli spin.
    #np.random.choice è una funzione che permette di estrarre campioni casuali
    #da un insieme di valori dati.
    #size(L, L) è una funzione di numpy specifica la forma dell'array 
    #risultante ed il tutto viene assegnato all'array lattice.
    lattice = np.random.choice([-1, 1], size=(L, L))
    #Se volessi la prima configurazione ordinata:
    #lattice = np.full((L, L), -1)

    #inizializza la matrice relativa all'energia media e la magnetizzazione
    #media per ogni step metropolis.
    energy_history = np.zeros(nmcs)
    magnetization_history = np.zeros(nmcs)

    # IMPOSTAZIONI VIDEO
    fps=8    
    target_frames = 200 #video di 25 secondi
    # Per evitare lo zero, risultante dal comando //, prendiamo 1
    intervallo_snapshot = max(1, nmcs // target_frames)  
    # Per fare il video in funzione della temperatura prendo gli ultimi 8 frame (1 sec) di configurazioni per ogni temperatura
    daStep = nmcs - fps*intervallo_snapshot
    immagini_frame = []
  
    for step in range(nmcs):
        metropolis_step_random(lattice, L, T, J)
        
        # Registrazione dei valori medi per particella (istantanei)
        E = calculate_total_energy(lattice, L, J)
        M = calculate_magnetization(lattice)
        
        energy_history[step] = E / N
        magnetization_history[step] = M / N

        if video:
            if step >= daStep and step % intervallo_snapshot == 0:
                nome_file = f"frame_{step}_T{T}.jpg"
                snapshot(lattice, T, step, nome_output=f"frame_{step}_T{T}")
                immagini_frame.append(nome_file)

    # Check per il video:
    print("Tipo di lista_immagini:", type(immagini_frame))
    print(f"Contenuto: {immagini_frame}")

    return energy_history, magnetization_history, immagini_frame, fps

def calc_c_avg(nmcs_start_avg, EvsStep, L, T):
    #This module calculates the heat capacity per spin from energy deviations in time
    N=L*L

    # Per trascurare il transiente:
    EvsStep_numpy = np.array(EvsStep)

    E_time_avg = np.mean(EvsStep_numpy[nmcs_start_avg:])
    Esqrd_time_avg = np.mean(EvsStep_numpy[nmcs_start_avg:] ** 2)
    c_avg=(Esqrd_time_avg-E_time_avg)/((T**2)*N)
    # ** si usa per elevare al quadrato gli elementi di un array NumPy
    # constants.k is the boltzmann constant K_B
    # K_B=1

    #print(E_time_avg)
    #print(Esqrd_time_avg)
    print(f"Heat capacity per spin from energy deviations in time: {c_avg}")

    return c_avg

def calc_X_avg(nmcs_start_avg, MvsStep, L, T):
    #This module calculates the heat capacity per spin from energy deviations in time
    N=L*L

    # Per trascurare il transiente:
    MvsStep_numpy = np.array(MvsStep)

    M_time_avg = np.mean(MvsStep_numpy[nmcs_start_avg:])
    Msqrd_time_avg = np.mean(MvsStep_numpy[nmcs_start_avg:] ** 2)
    X_avg=(Msqrd_time_avg-M_time_avg)/(T*N)
    # ** si usa per elevare al quadrato gli elementi di un array NumPy
    # constants.k is the boltzmann constant K_B
    # K_B=1

    #print(M_time_avg)
    #print(Msqrd_time_avg)
    print(f"Susceptibility per spin from energy deviations in time: {X_avg}")

    return X_avg
     
def energy_mag_vs_T(L, J, nmcs, T_i, T_f, delta_T, nmcs_start_avg, video):

    # Parametri
    n_T = int((T_f-T_i)/delta_T)
    energy_vs_T = []
    mag_vs_T = []
    c_vs_T = []
    X_vs_T = []
    T_steps = []
    immagini_frame = []

    vs="T"
    T=f"{T_i}-{T_f}"

    for i in range(n_T):
        t=T_i+i*delta_T
        T_steps.append(t)
        
        print(f"Avvio simulazione Modello di Ising 2D: L={L}, T={t}")
        energy_hist, mag_hist, framesAtT, fps = timeit(run_ising_simulation(L, t, J, nmcs))
        #print(f"energia passata:{energy_hist}")
        energy_vs_T.append(sum(energy_hist)/nmcs)
        #print(f"energia vettore nuovo:{energy_vs_T}")
        mag_vs_T.append(sum(mag_hist)/nmcs)

        # Per calcolare c e X:
        # energy_hist_numpy = np.array(energy_hist)
        # mag_hist_hist_numpy = np.array(mag_hist)
        c_vs_T.append(calc_c_avg(nmcs_start_avg, energy_hist, L, t))
        X_vs_T.append(calc_X_avg(nmcs_start_avg, mag_hist, L, t))

        # Per il video 
        immagini_frame.extend(framesAtT)
        
    print(f"n_T={n_T}")
    print(f"Lunghezza vettore energia={len(energy_vs_T)}")
    print(f"Lunghezza vettore magnetizzazione={len(mag_vs_T)}") 

    print(f"energia: {energy_vs_T}")   
    #print(f"energia: {mag_vs_T}")   
    
    plot(
        datiX=T_steps, 
        datiY1=energy_vs_T, 
        datiY2=mag_vs_T, 
        titoloPrincipale="Ising Model behavior", 
        titoloX="temperature", 
        titoloY="average values per spin", 
        titoloLegenda1="total energy", 
        titoloLegenda2="sample magnetization", 
        nome_output=f"ising_EMvs{vs}_L{L}_T{T}_J{J}"
    )

    plot(
        datiX=T_steps, 
        datiY1=c_vs_T, 
        datiY2=X_vs_T, 
        titoloPrincipale="Termalization properties", 
        titoloX="temperature", 
        titoloY="values per spin", 
        titoloLegenda1="heat capacity", 
        titoloLegenda2="susceptibility", 
        nome_output=f"ising_cXvs{vs}_L{L}_T{T}_J{J}_daStep{nmcs_start_avg}"
    )

    # Check per il video:
    print("Tipo di lista_immagini:", type(immagini_frame))
    print(f"Contenuto: {immagini_frame}")

    if video:
        crea_video_da_immagini(immagini_frame, fps, video_output=f"ising_L{L}_T{T_i}-{T_f}_J{J}.mp4")
    # (lista_immagini, fps, video_output)


def energy_mag_vs_step(L, J, nmcs, T, nmcs_start_avg, video):
    # ! La funzione metropolis_step che esegue i flip casualmente, se il numero nmcs non è adeguato, porta al fatto che alcuni spin potrebbero non essere mai capovolti. 

    # SIMULAZIONE
    energy_hist, mag_hist = run_ising_simulation(L, T, J, nmcs, video) #timeit(run_ising_simulation(L, T, J, nmcs, video))
    # Adattiamo al numero di step richiesto
    energy_hist = energy_hist[nmcs_start_avg:]
    mag_hist = mag_hist[nmcs_start_avg:]
    steps = np.arange(nmcs_start_avg, nmcs) 
    # La funzione arange di numpy permette di creare un array contenente il numero passato come primo argomento e generando numeri progressivi. 

    print("Simulazione completata con successo!")
    print(f"Ultimo valore stimato E/N: {energy_hist[-1]:.4f}")
    print(f"Ultimo valore stimato M/N: {mag_hist[-1]:.4f}")

    plot(
        datiX=steps, 
        datiY1=energy_hist, 
        datiY2=mag_hist, 
        titoloPrincipale="Ising Model Evolution", 
        titoloX="Monte Carlo steps", 
        titoloY="values per spin", 
        titoloLegenda1="total energy", 
        titoloLegenda2="sample magnetization", 
        nome_output=f"ising_EMvsSTEP_L{L}_T{T}_J{J}_step{nmcs_start_avg}-{nmcs}" #_step{nmcs_start_avg}-{nmcs}"
    )

    calc_c_avg(nmcs_start_avg, energy_hist, L, T)
    calc_X_avg(nmcs_start_avg, mag_hist, L, T)
    
    #snapshot(final_lattice, T, L, nome_output=f"ising_finalSnapshot_L{L}_T{T}_J{J}")
        
def main():
    # Parametri
    #L = 30 #numero di spin sul lato
    #Aumentare il numero di spin attenua le oscillazioni della magnetizzazione 
    #totale dovute alla temperatura che incentiva i flip a energia sfavorita.
    #T = 2.0 #temperatura
    #J = 1.0 #energia di scambio
    #nmcs = 1000  # Numero totale di passi Monte Carlo per spin
    #La funzione metropolis_step esegue i flip casualmente, quindi se il numero nmcs
    #non è adeguato, alcuni spin potrebbero non essere mai capovolti. 

    # stato=""
    # stato="provaDisp-1"
    # Esecuzione della simulazione
    #energy_hist, mag_hist, final_lattice = run_ising_simulation(L, T, J, nmcs)
    #steps = np.arange(1, nmcs + 1) #array all'aumentare degli step

    energy_mag_vs_step(
        L=30,
        J=1.0,
        nmcs=1000,
        T=2.0,
        nmcs_start_avg=0,
        video=True
    )

    # energy_mag_vs_step(
    #     L=30,
    #     J=1.0,
    #     nmcs=100,
    #     T=2.0,
    #     nmcs_start_avg=0,
    #     video=True
    # )
    
    # energy_mag_vs_step(
    #     L=30,
    #     J=1.0,
    #     nmcs=1000,
    #     T=4.0
    # )

    # energy_mag_vs_step(
    #     L=30,
    #     J=-1.0,
    #     nmcs=2000,
    #     T=2.0
    # )

    # energy_mag_vs_T(
    #     L=30,
    #     J=1.0,
    #     nmcs=1000,
    #     T_i = 1, #1.0
    #     T_f = 4, #4.0
    #     delta_T = 0.1,
    #     nmcs_start_avg = 0,
    #     video=True
    # )

    # energy_mag_vs_T(
    #     L=30,
    #     J=1.0,
    #     nmcs=1000,
    #     T_i = 1, #1.0
    #     T_f = 4, #4.0
    #     delta_T = 0.1,
    #     nmcs_start_avg = 250
    # )

    # T_i = 0 #1.0
    # T_f = 10 #4.0
    # delta_T = 0.5
    # n_T = int((T_f-T_i)/delta_T)
    #energy_vs_T = []
    #mag_vs_T = []
    #T_steps = []
    #n_T=int(n_T)


    #Al variare della temperatura
    stato=""
    vs="T"
    # T=f"{T_i}-{T_f}"

    # for i in range(n_T):
    #     t=T_i+i*delta_T
    #     T_steps.append(t)
    #     energy_hist, mag_hist, final_lattice = run_ising_simulation(L, t, J, nmcs)
    #     #print(f"energia passata:{energy_hist}")
    #     energy_vs_T.append(sum(energy_hist)/nmcs)
    #     #print(f"energia vettore nuovo:{energy_vs_T}")
    #     mag_vs_T.append(sum(mag_hist)/nmcs)
    #     print(f"Avvio simulazione Modello di Ising 2D: L={L}, T={t}")

    # print(f"n_T={n_T}")
    # print(f"Lunghezza vettore energia={len(energy_vs_T)}")
    # print(f"Lunghezza vettore magnetizzazione={len(mag_vs_T)}") 

    # print(f"energia: {energy_vs_T}")   
    #print(f"energia: {mag_vs_T}")   
    
    
    #print("Simulazione completata con successo!")
    #print(f"Ultimo valore stimato E/N: {energy_hist[-1]:.4f}")
    #print(f"Ultimo valore stimato M/N: {mag_hist[-1]:.4f}")

    

    # plot(
    #     datiX=T_steps, 
    #     datiY1=energy_vs_T, 
    #     datiY2=mag_vs_T, 
    #     titoloPrincipale="Ising Model steady state", 
    #     titoloX="temperature", 
    #     titoloY="average values per spin", 
    #     titoloLegenda1="total energy", 
    #     titoloLegenda2="sample magnetization", 
    #     nome_output=f"ising_EMvs{vs}_L{L}_T{T}_{stato}"
    # )

    #snapshot(final_lattice, T, L, nome_output=f"ising_finalSnapshot_L{L}_T{T}_{stato}")

if __name__ == "__main__":
    main()