import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import colormaps as cmaps
import time
import cv2
import os
from statistics import mean
from scipy import constants
from functools import wraps
from numba import njit
from matplotlib.font_manager import FontProperties
from matplotlib.patches import Patch
from matplotlib.colors import ListedColormap
from scipy.optimize import curve_fit

DIRECTORY = "/home/emanuele/Magistrale/LAB_COMP_I/"
#directory principale in cui si trova la cartella Ising Model

# >> WRAPPERS

def timeit(func):
    @wraps(func)
    #args e kwargs permettono a una funzione "wrapper" di accettare qualsiasi tipo di input senza sapere in anticipo quanti
    #o quali parametri riceverà la funzione originale
    def _func(*args, **kwargs):
        ti = time.time()
        res = func(*args, **kwargs)
        tf = time.time()
        dt = tf - ti
        print(f"Wall time: {dt:.6f} s")
        return res
    return _func

def separa_stampa(func):
    @wraps(func)
    def _wrapper(*args, **kwargs):
        #print("\n" + "+"*60)
        print("-"*60)
        #print(f">>> ESECUZIONE: {func.__name__}")
        #print("="*60)
        res = func(*args, **kwargs)
        print("-"*60 + "\n")
        return res
    return _wrapper

# >> GRAPHS

def plot1(datiX, datiY, titoloPrincipale, titoloX, titoloY,
         titoloLegenda, nome_output):
    # FONT
    times_font = FontProperties(family='Times New Roman', style='normal')
    times_dict = {'fontname': 'Times New Roman'}
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif']
    plt.rcParams['mathtext.fontset'] = 'stix'
    # CREAZIONE FIGURA
    fig, ax = plt.subplots(figsize=(7, 5), dpi=300)
    # GRAFICO
    ax.plot(
        datiX,
        datiY,
        color="#B22222",
        alpha=0.8,
        linewidth=0.8,
        label=titoloLegenda
    )
    # TITOLI
    ax.set_xlabel(titoloX, fontsize=16, labelpad=8)
    ax.set_ylabel(titoloY, fontsize=16, labelpad=8)
    ax.text(
        0.5, 0.95, titoloPrincipale,
        transform=ax.transAxes,
        fontsize=13,
        verticalalignment='top',
        horizontalalignment='center'
    )
    # LIMITI DINAMICI
    ymin, ymax = np.min(datiY), np.max(datiY)
    yrange = ymax - ymin
    if yrange == 0:
        yrange = max(abs(ymin), 1.0)
    xrange = np.max(datiX) - np.min(datiX)
    if xrange == 0:
        xrange = max(abs(np.min(datiX)), 1.0)
    ax.set_ylim(
        ymin - 0.05 * yrange,
        ymax + 0.35 * yrange
    )
    ax.set_xlim(
        np.min(datiX) - 0.02 * xrange,
        np.max(datiX) + 0.02 * xrange
    )
    # LEGENDA
    ax.legend(
        frameon=False,
        fontsize=11,
        loc='upper center',
        bbox_to_anchor=(0.7, 0.88)
    )
    # TICK
    ax.xaxis.set_major_locator(ticker.MaxNLocator(nbins=7))
    ax.yaxis.set_major_locator(ticker.MaxNLocator(nbins=7))
    ax.tick_params(
        axis='both',
        which='major',
        labelsize=12,
        direction='in',
        top=False,
        right=False
    )
    # FONT DEI TICK
    fig.canvas.draw()
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontfamily('serif')
        label.set_fontname('STIXGeneral')
    # SALVATAGGIO
    plt.tight_layout()
    plt.savefig(
        f'{nome_output}.jpg',
        format='jpeg',
        dpi=300
    )
    plt.close(fig)

def plot2(datiX, datiY1, datiY2, titoloPrincipale, titoloX, titoloY, titoloLegenda1, titoloLegenda2, nome_output):
    # FONT
    # Definizione esplicita delle proprietà del font Times New Roman
    times_font = FontProperties(family='Times New Roman', style='normal')
    times_dict = {'fontname': 'Times New Roman'}
    # Configurazione globale di backup
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif']
    plt.rcParams['mathtext.fontset'] = 'stix'
    # Mantiene lo stile Times anche per formule matematiche
    # print("Y1 min:", np.min(datiY1))
    # print("Y1 max:", np.max(datiY1))
    # #print("Y1 primi valori:", datiY1[:10])
    # print("Y2 min:", np.min(datiY2))
    # print("Y2 max:", np.max(datiY2))
    # Creazione della figura fig con dimensioni (width, height), ax sono gli assi
    fig, ax = plt.subplots(figsize=(7, 5), dpi=300)
    # SCATTERPLOT
    # Grafico a dispersione con punti adattati allo stile dell'istogramma. s è un parametro di size
    ax.plot(datiX, datiY1, color="#B22222", alpha=0.8, linewidth=0.8, label=titoloLegenda1)
    #ax.scatter(datiX, datiY1, color="#B22222", alpha=0.8, edgecolors="#B22222", linewidths=0.0, s=3, label=titoloLegenda1)
    # SCATTERPLOT 2 (Seconda serie di dati aggiunta, es. Energia Potenziale)
    ax.plot(datiX, datiY2, color="#00416D", alpha=0.8, linewidth=0.8, label=titoloLegenda2)
    #ax.scatter(datiX, datiY2, color="#00416D", alpha=0.8, edgecolors="#00416D", linewidths=0.0, s=3, label=titoloLegenda2)
    # TITOLI
    # Etichette degli assi e titolo interno
    ax.set_xlabel(titoloX, fontsize=16, labelpad=8)
    ax.set_ylabel(titoloY, fontsize=16, labelpad=8)
    # Posizione del titolo (centrato in alto)
    ax.text(0.5, 0.95, titoloPrincipale,
            transform=ax.transAxes, fontsize=13,
            verticalalignment='top', horizontalalignment='center')
    # Aumenta il limite Y massimo del 25% per creare spazio bianco in alto ( *1.25)
    # interval_max = max(ax.get_ylim()[1], ax.get_xlim()[1])
    # interval_min = min(ax.get_ylim()[0], ax.get_xlim()[0])
    # ax.set_ylim(interval_min, interval_max * 1.25)
    # ax.set_xlim(interval_min, interval_max * 1.25)
    # #stessa scala
    # ax.set_aspect('equal', adjustable='box')
    #AGGIUNTA DINAMICA
    all_y = np.concatenate([datiY1, datiY2])
    ymin, ymax = np.min(all_y), np.max(all_y)
    yrange = ymax - ymin
    # Crea dinamicamente uno spazio bianco extra in alto (\~35%) per titolo e legenda
    ax.set_ylim(ymin - 0.05 * yrange, ymax + 0.35 * yrange)
    ax.set_xlim(np.min(datiX) - 0.02 * (np.max(datiX) - np.min(datiX)),
                np.max(datiX) + 0.02 * (np.max(datiX) - np.min(datiX)))
    # LEGENDA
    # Impostazione della legenda (senza bordo/frame e centrata sotto il titolo)
    #ax.legend(frameon=False, fontsize=11, loc='upper center', bbox_to_anchor=(0.5, 0.88))
    ax.legend(frameon=False, fontsize=11, loc='upper center', bbox_to_anchor=(0.7, 0.88))
    # TICK
    # Gestione dei tick (max 6 punti per asse, tacche rivolte all'interno)
    ax.xaxis.set_major_locator(ticker.MaxNLocator(nbins=7))
    ax.yaxis.set_major_locator(ticker.MaxNLocator(nbins=7))
    # RIMOZIONE tick in alto e a destra (top=False, right=False)
    ax.tick_params(axis='both', which='major', labelsize=12, direction='in', top=False, right=False)
    # Forzatura del font sui numeri degli assi (tick labels)
    fig.canvas.draw()  # Genera i tick prima di modificarne le proprietà
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontfamily('serif')
        label.set_fontname('STIXGeneral')
    # SALVATAGGIO
    # Layout e salvataggio
    plt.tight_layout()
    # Salvataggio in formato JPEG e risoluzione
    plt.savefig(f'{nome_output}.jpg', format='jpeg', dpi=300)
    #plt.show()
    plt.close(fig)

def plot2error(datiX, datiY1, datiY2,
         titoloPrincipale, titoloX, titoloY,
         titoloLegenda1, titoloLegenda2,
         nome_output,
         erroriY1=None, erroriY2=None):
    # FONT
    times_font = FontProperties(family='Times New Roman', style='normal')
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif']
    plt.rcParams['mathtext.fontset'] = 'stix'
    fig, ax = plt.subplots(figsize=(7, 5), dpi=300)
    # CONTROLLO BARRE DI ERRORE
    for nome, errore, dati in [
        ("erroriY1", erroriY1, datiY1),
        ("erroriY2", erroriY2, datiY2)
    ]:
        if errore is not None:
            errore = np.asarray(errore, dtype=float)
            if errore.shape != np.asarray(dati).shape:
                raise ValueError(f"{nome} deve avere la stessa lunghezza dei dati!")
            if not np.all(np.isfinite(errore)) or np.any(errore < 0):
                raise ValueError(f"{nome} deve contenere valori finiti e non negativi!")
    # PRIMA SERIE
    ax.errorbar(
        datiX, datiY1,
        yerr=erroriY1,
        color="#B22222",
        alpha=0.8,
        linewidth=0.8,
        elinewidth=0.8,
        capsize=2,
        label=titoloLegenda1
    )
    # SECONDA SERIE
    ax.errorbar(
        datiX, datiY2,
        yerr=erroriY2,
        color="#00416D",
        alpha=0.8,
        linewidth=0.8,
        elinewidth=0.8,
        capsize=2,
        label=titoloLegenda2
    )
    # TITOLI
    ax.set_xlabel(titoloX, fontsize=16, labelpad=8)
    ax.set_ylabel(titoloY, fontsize=16, labelpad=8)
    ax.text(
        0.5, 0.95, titoloPrincipale,
        transform=ax.transAxes,
        fontsize=13,
        verticalalignment='top',
        horizontalalignment='center'
    )
    # LIMITI DINAMICI
    all_y = np.concatenate([datiY1, datiY2])
    ymin, ymax = np.min(all_y), np.max(all_y)
    yrange = ymax - ymin
    ax.set_ylim(
        ymin - 0.05 * yrange,
        ymax + 0.35 * yrange
    )
    ax.set_xlim(
        np.min(datiX) - 0.02 * (np.max(datiX) - np.min(datiX)),
        np.max(datiX) + 0.02 * (np.max(datiX) - np.min(datiX))
    )
    # LEGENDA
    ax.legend(
        frameon=False,
        fontsize=11,
        loc='upper center',
        bbox_to_anchor=(0.7, 0.88)
    )
    # TICK
    ax.xaxis.set_major_locator(ticker.MaxNLocator(nbins=7))
    ax.yaxis.set_major_locator(ticker.MaxNLocator(nbins=7))
    ax.tick_params(
        axis='both',
        which='major',
        labelsize=12,
        direction='in',
        top=False,
        right=False
    )
    fig.canvas.draw()
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontfamily('serif')
        label.set_fontname('STIXGeneral')
    # SALVATAGGIO
    plt.tight_layout()
    plt.savefig(
        f'{nome_output}.jpg',
        format='jpeg',
        dpi=300
    )
    plt.close(fig)

# >> FIT
# def fit_funzione(dati, f, p0=(1.0, 1.0, 0.0)):
#     # Estrazione dei dati
#     x = np.asarray(dati[:, 0], dtype=float)
#     y = np.asarray(dati[:, 1], dtype=float)
#     # Modello: A*f(x,B) + C
#     def modello(x, A, B, C):
#         return A * f(x, B) + C
#     # Fit
#     parametri, covarianza = curve_fit(
#         modello,
#         x,
#         y,
#         p0=p0[2:],
#         maxfev=20000
#     )
#     return parametri

@timeit
def fit_funzione(dati, f, p0):
    # Estrazione dei dati
    dati_arr = np.asarray(dati, dtype=float)
    x = dati_arr[:, 0]
    y = dati_arr[:, 1]

    # Modello con A fissato a 1: 1 * f(x, B) + C -> togliere A
    def modello(x, A, B, C):
        return A*f(x, B) + C
    # Fit (ora ottimizza solo B e C)
    parametri, covarianza = curve_fit(
        modello,
        x,
        y,
        p0=p0,
        maxfev=20000
    )
    return parametri

@njit
def f_esponenziale(x, B):
    return np.exp(-B*x)

def snapshot_berlin(final_lattice, T, step, nome_output):
    # FONT
    # Definizione esplicita delle proprietà del font Times New Roman
    times_font = FontProperties(family='Times New Roman', style='normal')
    # Configurazione globale di backup
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif']
    plt.rcParams['mathtext.fontset'] = 'stix'
    # Mantiene lo stile Times anche per formule matematiche
    #plt.register_cmap(name='viridis', cmap=cmaps.viridis)
    #plt.set_cmap(cmaps.viridis)
    #img=mpimg.imread('stinkbug.png')
    #lum_img = np.flipud(img[:,:,0])
    #imgplot = plt.pcolormesh(lum_img)
    # Generazione dello snapshot
    #Alternativamente posso decidere io i colori per l'oggetto cmap
    #cmap = ListedColormap(['#00416D', '#B22222'])
    fig, ax = plt.subplots(figsize=(5, 5), dpi=300) #figure and axes
    ax.imshow(final_lattice, cmap='berlin',
                interpolation='nearest')
    ax.set_title(f"Spin configuration for $T = {T:.2f}$",
                fontsize=12)
    # LEGENDA
    cmap = plt.get_cmap('berlin')
    legenda = [
        Patch(facecolor=cmap(1.0), label=r"$s_i = +1$"),
        Patch(facecolor=cmap(0.0), label=r"$s_i = -1$")
    ]
    ax.legend(handles=legenda,
            loc='upper center',
            bbox_to_anchor=(0.5, -0.08),
            ncol=2,
            frameon=False,
            fontsize=12)
    # SALVATAGGIO
    plt.tight_layout()
    plt.savefig(f"{nome_output}.jpg",
                format='jpeg', dpi=300, bbox_inches='tight')
    #plt.show()
    plt.close(fig)
#snapshot in viridis

def snapshot_viridis(final_lattice, T, step, nome_output):
    # FONT
    # Definizione esplicita delle proprietà del font Times New Roman
    times_font = FontProperties(family='Times New Roman', style='normal')
    # Configurazione globale di backup
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif']
    plt.rcParams['mathtext.fontset'] = 'stix'
    # Mantiene lo stile Times anche per formule matematiche
    #plt.register_cmap(name='viridis', cmap=cmaps.viridis)
    #plt.set_cmap(cmaps.viridis)
    #img=mpimg.imread('stinkbug.png')
    #lum_img = np.flipud(img[:,:,0])
    #imgplot = plt.pcolormesh(lum_img)
    # Generazione dello snapshot
    #Alternativamente posso decidere io i colori per l'oggetto cmap
    #cmap = ListedColormap(['#00416D', '#B22222'])
    fig, ax = plt.subplots(figsize=(5, 5), dpi=300) #figure and axes
    ax.imshow(final_lattice, cmap='viridis',
                interpolation='nearest')
    ax.set_title(f"Spin configuration for $T = {T:.2f}$",
                fontsize=12)
    # LEGENDA
    cmap = plt.get_cmap('viridis')
    legenda = [
        Patch(facecolor=cmap(1.0), label=r"$s_i = +1$"),
        Patch(facecolor=cmap(0.0), label=r"$s_i = -1$")
    ]
    ax.legend(handles=legenda,
            loc='upper center',
            bbox_to_anchor=(0.5, -0.08),
            ncol=2,
            frameon=False,
            fontsize=12)
    # SALVATAGGIO
    plt.tight_layout()
    plt.savefig(f"{nome_output}.jpg",
                format='jpeg', dpi=300, bbox_inches='tight')
    #plt.show()
    plt.close(fig)

def crea_video_da_immagini(lista_immagini, fps, video_output):
    if not lista_immagini:
        print("La lista delle immagini è vuota!")
        return
    # Leggi la prima immagine per ricavare larghezza e altezza (risoluzione)
    frame_esempio = cv2.imread(lista_immagini[0])
    if frame_esempio is None:
        print(f"Errore nella lettura del file: {lista_immagini[0]}")
        res = None
        return
    altezza, larghezza, canali = frame_esempio.shape
    # Imposta il codec video per il formato .mp4 ('mp4v' è ampiamente compatibile)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    # Inizializza l'oggetto VideoWriter
    video_writer = cv2.VideoWriter(video_output, fourcc, fps, (larghezza, altezza))
    print(f"Sto generando il video ({video_output})...")
    for nome_file in lista_immagini:
        frame = cv2.imread(nome_file)
        if frame is not None:
            video_writer.write(frame)  # Scrive il frame nel video
        else:
            print(f"Attenzione: impossibile leggere {nome_file}, saltato.")
    # Rilascia e chiude il file video
    video_writer.release()
    print("Video completato e salvato con successo!")
    # Facoltativo: elimina i file JPG temporanei dopo aver fatto il video
    for nome_file in lista_immagini:
        if os.path.exists(nome_file):
            os.remove(nome_file)

# >> ANALYSIS
#@njit

@njit
def calc_error_bar(data, n_seeds):
    # Rimozione del transiente, non serve
    data = np.asarray(data, dtype=np.float64)
    n = len(data)
    # Check
    print(f"La lunghezza di qualsiasi cosa stia calcolando le error bar è: {n}")
    print(f"Valore per cui dividere la deviazione = {n} e {n_seeds}")
    if n < 2:
        raise ValueError("Servono almeno due misurazioni!")
    # Deviazione standard campionaria
    sigma = np.std(data) * np.sqrt(n / (n - 1))
    # Errore statistico sulla media
    error = sigma / np.sqrt(n)
    return error

#@timeit
@njit
def _calc_autocorrelation_numba(E, max_lag):
    delta_E = E - np.mean(E)
    normalize = np.sum(delta_E**2)
    # Calcolo dell'autocorrelazione
    rho = np.empty(max_lag, dtype=np.float64)
    step_totali = len(E)
    for k in range(max_lag):
        if k < step_totali:
            somma = np.dot(delta_E[:step_totali-k], delta_E[k:])
            rho[k] = somma / normalize
        else:
            rho[k] = 0.0
    return rho

@timeit
def _calc_autocorrelation_fft(E, max_lag):

    E = np.asarray(E, dtype=np.float64)

    N = len(E)

    # Sottrazione della media
    delta_E = E - np.mean(E)

    # Normalizzazione identica alla tua formula
    normalize = np.sum(delta_E**2)

    # Output
    rho = np.zeros(max_lag, dtype=np.float64)

    # Numero di lag effettivamente calcolabili
    n_lags = min(max_lag, N)

    if n_lags == 0:
        return rho

    # Zero-padding: lunghezza FFT >= 2*N - 1
    n_fft = 1 << (2 * N - 2).bit_length()

    # FFT
    fft_E = np.fft.rfft(delta_E, n=n_fft)

    # Spettro di potenza
    power_spectrum = fft_E * np.conjugate(fft_E)

    # Trasformata inversa
    autocorr = np.fft.irfft(power_spectrum, n=n_fft)

    # Normalizzazione
    rho[:n_lags] = autocorr[:n_lags] / normalize

    return rho

#@njit
@timeit
def calc_autocorrelation(E_history, L, T, nmcs_eq, max_lag, nome_file):
    E = np.asarray(E_history, dtype=float)
    step_totali = len(E)
    N = L * L
    # Controlli
    if step_totali != max_lag + 1:
        print(f"-calc_autocorrelation, attenzione step_totali={step_totali} != max_lag={max_lag+1}")
    if step_totali < 2:
        raise ValueError("-calc_autocorrelation, servono almeno due valori di energia!")
    if np.var(E) == 0:
        raise ValueError("-calc_autocorrelation, la varianza dell'energia è nulla!")
    # Calcolo dell'autocorrelazione
    #rho = _calc_autocorrelation_numba(E, max_lag)
    rho = _calc_autocorrelation_fft(E, max_lag)
    lag = np.arange(max_lag)
    #print("Plotto l'autocorrelazione prima del ricampionamento")
    # Grafico
    # plot1(
    #     datiX=lag,
    #     datiY=rho,
    #     titoloPrincipale=f"Autocorrelation function for L={30} and T={T}",
    #     titoloX="k",
    #     titoloY="$\rho$",
    #     titoloLegenda="Autocorrelation",
    #     nome_output=f"try_autocorr_task1_L{L}_T{T}_{nmcs_eq}"
    # )
    print(f"-calc_autocorrelation, len(rho)={len(rho)}, len(lag)={len(lag)}")
    # Conversione e selezione degli indici
    # conversione_step = int((max_lag + 1) / N)
    # indici = np.linspace(
    #     0,
    #     len(lag) - 1,
    #     conversione_step-1,
    #     dtype=int
    # )
    # lag = lag[indici]
    # rho = rho[indici]
    # print(f" ricampionamento, len(rho)={len(rho)}, len(lag)={len(lag)}")
    # Salvataggio
    # np.savetxt(
    #     nome_file,
    #     np.column_stack((lag, rho)),
    #     delimiter='\t',
    #     header="t_MCS\trho_E",
    #     fmt="%.10e",
    #     comments="# "
    # )
    return rho

# >> SIMULATION

#(3)
#@njit

@njit
def calculate_total_energy(lattice, L, J, obc):
    """
    Calcola l'energia totale del sistema considerando i
    vicini primi con condizioni al contorno periodiche (PBC).
    """
    energy = 0.0
    for i in range(L):
        for j in range(L):
            s = lattice[i, j]
            if obc:
                # Interazione con lo spin sottostante
                if i + 1 < L:
                    energy += -J * s * lattice[i + 1, j]
                # Interazione con lo spin a destra
                if j + 1 < L:
                    energy += -J * s * lattice[i, j + 1]
            else:
                # Somma sui vicini di destra e in basso per evitare doppi conteggi
                neighbors = lattice[(i + 1) % L, j] + lattice[i, (j + 1) % L]
                #H_ising=-J*sum(s*S)
                energy += -J * s * neighbors
    return energy
#@njit

@njit
def calculate_magnetization(lattice):
    """Calcola la magnetizzazione totale del reticolo."""
    #la magnetizzazione del reticolo è semplicemente lo spin totale
    return np.sum(lattice)

#(2)
#@njit

@njit
def metropolis_step_random(lattice, L, T, J, obc, step,
                           energy_history, magnetization_history):
    N = L * L
    # Energia e magnetizzazione iniziali del reticolo.
    # Vengono calcolate una sola volta per ogni MCS.
    E = calculate_total_energy(lattice, L, J, obc)
    M = int(np.sum(lattice))
    # Probabilità di accettazione precalcolate.
    # k = s * neighbors può assumere valori da -4 a +4.
    probabilita = np.exp(
        -2.0 * J * np.arange(-4, 5, dtype=np.float64) / T
    )
    for _ in range(N):
        # Selezione casuale dello spin
        i = np.random.randint(0, L)
        j = np.random.randint(0, L)
        s = lattice[i, j]
        # Calcolo dei vicini
        if obc:
            neighbors = 0
            if i + 1 < L:
                neighbors += lattice[i + 1, j]
            if i - 1 >= 0:
                neighbors += lattice[i - 1, j]
            if j + 1 < L:
                neighbors += lattice[i, j + 1]
            if j - 1 >= 0:
                neighbors += lattice[i, j - 1]
        else:
            neighbors = (
                lattice[(i + 1) % L, j] +
                lattice[(i - 1) % L, j] +
                lattice[i, (j + 1) % L] +
                lattice[i, (j - 1) % L]
            )
        # Variazione di energia associata al flip
        k = int(s * neighbors)
        delta_E = 2.0 * J * k
        # Criterio di Metropolis
        accepted = False
        if delta_E <= 0.0:
            accepted = True
        elif np.random.rand() < probabilita[k + 4]:
            accepted = True
        # Aggiornamento incrementale
        if accepted:
            lattice[i, j] = -s
            E += delta_E
            M -= 2 * s
        # Registrazione dei valori per spin
        #print(step)
        energy_history[step] = E / N
        magnetization_history[step] = M / N
        step += 1
    return step

@njit
def metropolis_step_ordered_horizontal(lattice, L, T, J, obc, step,
                                        energy_history, magnetization_history):
    N = L * L
    # Energia e magnetizzazione iniziali
    E = calculate_total_energy(lattice, L, J, obc)
    M = int(np.sum(lattice))
    # Probabilità di accettazione precalcolate
    probabilita = np.exp(
        -2.0 * J * np.arange(-4, 5, dtype=np.float64) / T
    )
    # Scansione ordinata del reticolo
    for i in range(L):
        for j in range(L):
            s = lattice[i, j]
            # Calcolo dei vicini
            if obc:
                neighbors = 0
                if i + 1 < L:
                    neighbors += lattice[i + 1, j]
                if i - 1 >= 0:
                    neighbors += lattice[i - 1, j]
                if j + 1 < L:
                    neighbors += lattice[i, j + 1]
                if j - 1 >= 0:
                    neighbors += lattice[i, j - 1]
            else:
                neighbors = (
                    lattice[(i + 1) % L, j] +
                    lattice[(i - 1) % L, j] +
                    lattice[i, (j + 1) % L] +
                    lattice[i, (j - 1) % L]
                )
            # Variazione di energia
            k = int(s * neighbors)
            delta_E = 2.0 * J * k
            # Criterio di Metropolis
            accepted = False
            if delta_E <= 0.0:
                accepted = True
            elif np.random.rand() < probabilita[k + 4]:
                accepted = True
            # Aggiornamento incrementale
            if accepted:
                lattice[i, j] = -s
                E += delta_E
                M -= 2 * s
            # Registrazione dei valori per spin
            #print(step)
            energy_history[step] = E / N
            magnetization_history[step] = M / N
            step += 1
    return step

#(1)
#@timeit
#@njit

@separa_stampa
def run_ising_simulation(L, T, J, lattice, nmcs, video, viridis, ordered, obc):
    """
    Esegue la simulazione salvando l'andamento istantaneo
    di energia e magnetizzazione per ogni passo Monte Carlo.
    """
    N = L * L
    #Inizializziamo il modello con una distribuzione casuale degli spin.
    #np.random.choice è una funzione che permette di estrarre campioni casuali
    #da un insieme di valori dati.
    #size(L, L) è una funzione di numpy specifica la forma dell'array
    #risultante ed il tutto viene assegnato all'array lattice.
    # seed = int.from_bytes(os.urandom(4), byteorder="big")
    # np.random.seed(seed)
    # print(f"Simulazione L={L}, T={T} -> Seed utilizzato: {seed}")
    # lattice = np.random.choice([-1, 1], size=(L, L))
    #Se volessi la prima configurazione ordinata:
    #lattice = np.full((L, L), -1)
    # #inizializza la matrice relativa all'energia media e la magnetizzazione
    # #media per ogni step metropolis.
    energy_history = np.zeros(nmcs)
    magnetization_history = np.zeros(nmcs)
    # IMPOSTAZIONI VIDEO
    fps=8
    target_frames = 200 #video di 25 secondi
    # Per evitare lo zero, risultante dal comando //, prendiamo 1
    intervallo_snapshot = max(1, nmcs // target_frames)
    immagini_frame = []
    step=0
    #for step in range(nmcs):
    while True:
        if step==nmcs:
            print(f"-run_ising_simulation, ciclo interrotto: step {step} == nmcs {nmcs}")
            break
        #step += 1
        #print(f"Esecuzione step numero: {step}")
        # if comando.lower() == 'esci':
        #     print("Ciclo interrotto.")
        #     break
        #print(f"Imposto macroStep = {macroStep}")
        #print(f"Entro con step = {step}")
        if ordered:
            step=metropolis_step_ordered_horizontal(lattice, L, T, J, obc, step, energy_history, magnetization_history)
        else:
            step=metropolis_step_random(lattice, L, T, J, obc, step, energy_history, magnetization_history)
        #metropolis_step_ordered_horizontal(lattice, L, T, J)
        #print("Confermo")
        # # Registrazione dei valori medi per particella (istantanei)
        # E = calculate_total_energy(lattice, L, J, obc)
        # M = calculate_magnetization(lattice)
        # energy_history[step] = E / N
        # magnetization_history[step] = M / N
        if video:
            if step % intervallo_snapshot == 0:
                nome_file = f"frame_{step}.jpg"
                if viridis:
                    snapshot_viridis(lattice, T, step, nome_output=f"frame_{step}")
                else:
                    snapshot_berlin(lattice, T, step, nome_output=f"frame_{step}")
                immagini_frame.append(nome_file)
        # if step==nmcs:
        #     print("Ciclo interrotto.")
        #     break
        #step=macroStep*N
    # Check per il video:
    print("-run_ising_simulation, tipo di lista_immagini:", type(immagini_frame))
    #print("Contenuto di lista_immagini[0]:", repr(immagini_frame[0]), "Tipo:", type(immagini_frame[0]))
    if video:
        crea_video_da_immagini(immagini_frame, fps, video_output=f"ising_L{L}_T{T}_J{J}.mp4")
    # (lista_immagini, fps, video_output)
    return energy_history, magnetization_history, lattice

@separa_stampa
#@njit
def run_ising_simulation_videoT(lattice, L, T, J, nmcs, video, viridis, ordered, obc):
    """
    Esegue la simulazione salvando l'andamento istantaneo
    di energia e magnetizzazione per ogni passo Monte Carlo.
    """
    N = L * L
    # #inizializza la matrice relativa all'energia media e la magnetizzazione
    # #media per ogni step metropolis.
    energy_history = np.zeros(nmcs)
    magnetization_history = np.zeros(nmcs)
    # IMPOSTAZIONI VIDEO
    fps=8
    target_frames = 200 #video di 25 secondi
    # Per evitare lo zero, risultante dal comando //, prendiamo 1
    intervallo_snapshot = max(1, nmcs // target_frames)
    # Per fare il video in funzione della temperatura prendo gli ultimi 8 frame (1 sec) di configurazioni per ogni temperatura
    daStep = nmcs - fps*intervallo_snapshot
    immagini_frame = []
    step=0
    while True:
        if step==nmcs:
            print(f"-run_ising_simulation_videoT, ciclo interrotto: step {step} == nmcs {nmcs}")
            break
        if ordered:
            step=metropolis_step_ordered_horizontal(lattice, L, T, J, obc, step, energy_history, magnetization_history)
        else:
            step=metropolis_step_random(lattice, L, T, J, obc, step, energy_history, magnetization_history)
        #print("Confermo")
        # # Registrazione dei valori medi per particella (istantanei)
        # E = calculate_total_energy(lattice, L, J, obc)
        # M = calculate_magnetization(lattice)
        # energy_history[step] = E / N
        # magnetization_history[step] = M / N
        if video:
            if step >= daStep and step % intervallo_snapshot == 0:
                nome_file = f"frame_{step}_T{T}"
                if viridis:
                    snapshot_viridis(lattice, T, step, nome_output=nome_file)
                else:
                    snapshot_berlin(lattice, T, step, nome_output=nome_file)
                immagini_frame.append(f"{nome_file}.jpg")
        # if step==nmcs:
        #     print(f"Ciclo interrotto: step {step} == nmcs {nmcs}")
        #     break
    # Check per il video:
    print("-run_ising_simulation_videoT, tipo di lista_immagini:", type(immagini_frame))
    #print(f"Contenuto: {immagini_frame}")
    return energy_history, magnetization_history, immagini_frame, fps, lattice
#@njit

@njit
def calc_c_avg(EvsStep, L, T):
    #This module calculates the heat capacity per spin from energy deviations in time
    N=L*L
    # Per trascurare il transiente:
    EvsStep_numpy = np.empty(len(EvsStep), dtype=np.float64)
    for i in range(len(EvsStep)):
        EvsStep_numpy[i] = EvsStep[i] * N
    E_time_avg = np.mean(EvsStep_numpy[:])
    Esqrd_time_avg = np.mean(EvsStep_numpy[:] ** 2)
    c_avg=(Esqrd_time_avg-E_time_avg**2)/(N*(T**2))
    # ** si usa per elevare al quadrato gli elementi di un array NumPy
    # constants.k is the boltzmann constant K_B
    # K_B=1
    #print(E_time_avg)
    #print(Esqrd_time_avg)
    print("-run_ising_simulation_videoT, heat capacity per spin from energy deviations in time:", c_avg)
    return c_avg
#@njit

@njit
def calc_c_derivative(T_values, energy_vs_T):
    # print("-calc_c_derivative,")
    # print("Temperatura:")
    # print(T_values)
    # print("Energia:")
    # print(energy_vs_T)
    T_values = np.asarray(T_values, dtype=np.float64)
    energy_vs_T = np.asarray(energy_vs_T, dtype=np.float64)
    if len(T_values) != len(energy_vs_T):
        raise ValueError("I vettori devono avere la stessa lunghezza!")
    if len(T_values) < 2:
        raise ValueError("Servono almeno due temperature!")
    if np.any(np.diff(T_values) <= 0):
        raise ValueError("Le temperature devono essere crescenti!")
    # Derivata numerica dell'energia media per spin rispetto a T
    n = len(T_values)
    c_derivative = np.empty(n, dtype=np.float64)
    # Differenze finite ai bordi (edge_order=1)
    c_derivative[0] = (energy_vs_T[1] - energy_vs_T[0]) / (T_values[1] - T_values[0])
    c_derivative[-1] = (energy_vs_T[-1] - energy_vs_T[-2]) / (T_values[-1] - T_values[-2])
    # Differenze centrate per i punti interni, valide anche per temperature non equispaziate
    for i in range(1, n - 1):
        dx1 = T_values[i] - T_values[i - 1]
        dx2 = T_values[i + 1] - T_values[i]
        a = -dx2 / (dx1 * (dx1 + dx2))
        b = (dx2 - dx1) / (dx1 * dx2)
        c = dx1 / (dx2 * (dx1 + dx2))
        c_derivative[i] = (
            a * energy_vs_T[i - 1]
            + b * energy_vs_T[i]
            + c * energy_vs_T[i + 1]
        )
    return c_derivative
#@njit

@njit
def calc_X_avg(MvsStep, L, T):
    #This module calculates the heat capacity per spin from energy deviations in time
    N=L*L
    # Per trascurare il transiente:
    MvsStep_numpy = np.empty(len(MvsStep), dtype=np.float64)
    for i in range(len(MvsStep)):
        MvsStep_numpy[i] = MvsStep[i] * N
    Mmod_time_avg = np.mean(np.abs(MvsStep_numpy[:]))
    Msqrd_time_avg = np.mean(MvsStep_numpy[:] ** 2)
    X_avg=(Msqrd_time_avg-Mmod_time_avg**2)/(T*N)
    # ** si usa per elevare al quadrato gli elementi di un array NumPy
    # constants.k is the boltzmann constant K_B
    # K_B=1
    #print(M_time_avg)
    #print(Msqrd_time_avg)
    print("-calc_X_avg, susceptibility per spin from energy deviations in time:", X_avg)
    return X_avg

# >> CONFIGS
#@njit
@timeit
#@separa_stampa
def energy_mag_vs_T(L, J, nmcs, T_i, T_f, delta_T, nmcs_eq, video, viridis, ordered, obc, n_seeds):
    # Parametri
    N=L*L
    #n_T = int((T_f-T_i)/delta_T)
    n_T = int(round((T_f-T_i)/delta_T)) + 1
    # energy_vs_T = []
    # mag_vs_T = []
    # c_vs_T = []
    # X_vs_T = []
    T_steps = []
    immagini_frame = []
    # error bars
    error_energy_vs_T = []
    error_mag_vs_T = []
    energy_vs_T_seed = [] # Matrice bidimensionale con temperature diverse sulle colonne, le righe per i seed
    mag_vs_T_seed = []
    energy_vs_T_seed_avg = []
    mag_vs_T_seed_avg = []
    c_vs_T_seed = []
    X_vs_T_seed = []
    c_vs_T_seed_avg = []
    X_vs_T_seed_avg = []
    vs="T"
    T=f"{T_i}-{T_f}"
    seed_in=42
    # energy_hist = np.zeros(nmcs)
    # mag_hist = np.zeros(nmcs)
    T_steps = [
        T_i + i*delta_T
        for i in range(n_T)
    ]
    # Faccio la media dell'energia e della magnetizzazione su più seed
    for j in range(n_seeds): # range(n) arriva a n-1
        seed=seed_in+j
        # Inizializzazione lattice
        np.random.seed(int(seed))
        print("\n" + "+"*60)
        print(f"-energy_mag_vs_T, seed utilizzato: {seed}")
        print("\n" + "+"*60)
        # lattice = np.random.choice([-1, 1], size=(L, L))
        lattice = np.full((L, L), +1)
        energy_vs_T = []
        mag_vs_T = []
        c_vs_T = []
        X_vs_T = []
        for i in range(n_T):
            t=T_i+i*delta_T
            #T_steps.append(t)
            print(f"-energy_mag_vs_T, avvio simulazione Modello di Ising 2D: L={L}, T={t}")
            # The final spin configuration at temperature $T_1$ becomes the starting configuration for temperature $T_2$
            if nmcs_eq !=0:
                energy_hist, mag_hist, framesAtT, fps, lattice = run_ising_simulation_videoT(lattice, L, t, J, nmcs_eq, video, viridis, ordered, obc)
            energy_hist, mag_hist, framesAtT, fps, lattice = run_ising_simulation_videoT(lattice, L, t, J, nmcs, video, viridis, ordered, obc)
            energy_vs_T.append(sum(energy_hist)/nmcs)
            mag_hist_abs= [abs(x) for x in mag_hist]
            mag_vs_T.append(sum(mag_hist_abs)/nmcs)
            c_vs_T.append(calc_c_avg(energy_hist, L, t))
            X_vs_T.append(calc_X_avg(mag_hist, L, t))
            # Per il video
            immagini_frame.extend(framesAtT)
        energy_vs_T_seed.append(energy_vs_T)
        mag_vs_T_seed.append(mag_vs_T)
        # Per calcolare c e X:
        # c_vs_T.append(calc_c_avg(energy_hist, L, t))
        # X_vs_T.append(calc_X_avg(mag_hist, L, t))
        c_vs_T_seed.append(c_vs_T)
        X_vs_T_seed.append(X_vs_T)
        #seed=seed_in+j
    energy_vs_T_seed_avg=[sum(col)/n_seeds for col in zip(*energy_vs_T_seed)]
    mag_vs_T_seed_avg=[sum(col)/n_seeds for col in zip(*mag_vs_T_seed)]
    c_vs_T_seed_avg=[sum(col)/n_seeds for col in zip(*c_vs_T_seed)]
    X_vs_T_seed_avg=[sum(col)/n_seeds for col in zip(*X_vs_T_seed)]
    # error_energy_vs_T.append(calc_error_bar(energy_vs_T_seed_avg, n_seeds))
    # error_mag_vs_T.append(calc_error_bar(mag_vs_T_seed_avg, n_seeds))
    error_energy_vs_T = (
    np.std(energy_vs_T_seed, axis=0, ddof=1)
        / np.sqrt(n_seeds)
    )
    error_mag_vs_T = (
        np.std(mag_vs_T_seed, axis=0, ddof=1)
        / np.sqrt(n_seeds)
    )
    print(f"-energy_mag_vs_T, n_T={n_T}")
    print(f"-energy_mag_vs_T, lunghezza vettore energia={len(energy_vs_T)}")
    print(f"-energy_mag_vs_T, lunghezza vettore magnetizzazione={len(mag_vs_T)}")
    #print(f"-energy_mag_vs_T, energia: {energy_vs_T}")
    #print(f"energia: {mag_vs_T}")
    plot2error(
        datiX=T_steps,
        datiY1=energy_vs_T_seed_avg,
        datiY2=mag_vs_T_seed_avg,
        titoloPrincipale="Ising Model behavior on many runs",
        titoloX="temperature",
        titoloY="values",
        titoloLegenda1="energy per spin",
        titoloLegenda2="abs. magnetization per spin",
        nome_output=f"ising_EMvs{vs}_L{L}_T{T}_J{J}",
        erroriY1=error_energy_vs_T,
        erroriY2=error_mag_vs_T
    )
    #plot1(datiX, datiY, titoloPrincipale, titoloX, titoloY, titoloLegenda, nome_output)
    plot1(
        datiX=T_steps,
        datiY=X_vs_T_seed_avg,
        titoloPrincipale="Magnetic susceptibility on many runs",
        titoloX="temperature",
        titoloY="values",
        titoloLegenda="susceptibility per spin",
        nome_output=f"ising_XvsT_L{L}_T{T}_J{J}_daStep{nmcs_eq}"
    )
    cDer_vs_T=calc_c_derivative(T_steps, energy_vs_T_seed_avg)
    plot2(
        datiX=T_steps,
        datiY1=c_vs_T_seed_avg,
        datiY2=cDer_vs_T,
        titoloPrincipale="heat capacity per spin on many runs",
        titoloX="temperature",
        titoloY="values",
        titoloLegenda1="from energy variance",
        titoloLegenda2="from derivative",
        nome_output=f"ising_CvsCder_L{L}_T{T}_J{J}_daStep{nmcs_eq}"
    )
    # Check per il video:
    print("-energy_mag_vs_T, tipo di lista_immagini:", type(immagini_frame))
    #print(f"Contenuto: {immagini_frame}")
    if video:
        crea_video_da_immagini(immagini_frame, fps, video_output=f"ising_L{L}_T{T_i}-{T_f}_J{J}.mp4")
    # (lista_immagini, fps, video_output)
##@njit

@timeit
#@separa_stampa
def energy_mag_vs_step(L, J, nmcs, T, nmcs_eq, video, viridis, ordered, obc, n_seeds, max_lag):
    # ! La funzione metropolis_step che esegue i flip casualmente, se il numero nmcs non è adeguato, porta al fatto che alcuni spin potrebbero non essere mai capovolti.
    N=L*L
    # Inizializzazione lattice
    # seed=42
    # np.random.seed(42)
    # print(f"Simulazione L={L}, T={T} -> Seed utilizzato: {seed}")
    # lattice = np.random.choice([-1, 1], size=(L, L))
    #lattice = np.full((L, L), +1)
    seed_in=42
    energy_hist = np.zeros(nmcs)
    mag_hist = np.zeros(nmcs)
    rho_seed = []
    #max_lag = 90000#int((nmcs-1)/4)
    print(f"-energy_mag_vs_step, max_lag = {max_lag}")
    # energy_vs_T_seed = [] # Matrice bidimensionale con temperature diverse sulle colonne, le righe per i seed
    # mag_vs_T_seed = []
    # energy_vs_T_seed_avg = []
    # mag_vs_T_seed_avg = []
    # c_vs_T_seed = []
    # X_vs_T_seed = []
    # c_vs_T_seed_avg = []
    # X_vs_T_seed_avg = []
    # SIMULAZIONE e media su seed
   # Faccio la media dell'energia e della magnetizzazione su più seed
    for j in range(n_seeds): # range(n) arriva a n-1
        seed=seed_in+j
        np.random.seed(int(seed))
        print("\n" + "+"*60)
        print(f"-energy_mag_vs_step, seed utilizzato: {seed}")
        print("\n" + "+"*60)
        lattice = np.random.choice([-1, 1], size=(L, L))
        #lattice = np.full((L, L), +1)
        if nmcs_eq !=0:
            energy_hist_seed, mag_hist_seed, lattice = run_ising_simulation(L, T, J, lattice, nmcs_eq, video, viridis, ordered, obc) #timeit(run_ising_simulation(L, T, J, nmcs, video))
        energy_hist_seed, mag_hist_seed, lattice = run_ising_simulation(L, T, J, lattice, nmcs, video, viridis, ordered, obc) #timeit(run_ising_simulation(L, T, J, nmcs, video))
        # calc_c_avg(energy_hist_seed, L, T)
        # calc_X_avg(mag_hist_seed, L, T)
        rho_seed.append(calc_autocorrelation(
                E_history=energy_hist_seed,
                L=L,
                T=T,
                nmcs_eq=nmcs_eq,
                max_lag = max_lag,
                nome_file=f"{DIRECTORY}Ising_model/task5/rhoTask1_L{L}_T{T}_step{nmcs_eq}-{nmcs}.txt"
            )
        )
        #energy_hist_seed=np.array(energy_hist_seed, dtype=float)
        #mag_hist_seed=np.array(mag_hist_seed, dtype=float)
        energy_hist+=energy_hist_seed
        mag_hist+=mag_hist_seed
        #seed=seed_in+j
    energy_hist=energy_hist/n_seeds
    mag_hist=mag_hist/n_seeds
    rho=[sum(col)/n_seeds for col in zip(*rho_seed)]
    
    steps = np.arange(nmcs)
    print(f"-energy_mag_vs_step, lunghezza step {len(steps)}")
    # La funzione arange di numpy permette di creare un array contenente il numero passato come primo argomento e generando numeri progressivi.
    print("-energy_mag_vs_step, Simulazione completata con successo!")
    print(f"-energy_mag_vs_step, ultimo valore stimato E/N: {energy_hist[-1]:.4f}")
    print(f"-energy_mag_vs_step, ultimo valore stimato M/N: {mag_hist[-1]:.4f}")
    plot2(
        datiX=steps,
        datiY1=energy_hist,
        datiY2=mag_hist,
        titoloPrincipale="Ising Model Evolution",
        titoloX="Monte Carlo steps",
        titoloY="values per spin",
        titoloLegenda1="energy per spin",
        titoloLegenda2="abs. magnetization per spin",
        nome_output=f"ising_EMvsSTEP_L{L}_T{T}_J{J}_step{nmcs_eq}-{nmcs}" #_step{nmcs_eq}-{nmcs}"
    )
    lag = np.arange(len(rho))

    np.savetxt(
        f"{DIRECTORY}Ising_model/task5/rhoTask1_L{L}_T{T}_step{nmcs_eq}-{nmcs}.txt",
        np.column_stack((lag, rho)),
        delimiter='\t',
        header="t_MCS\trho_E",
        fmt="%.10e",
        comments="# "
    )

    print(f"-energy_mag_vs_step, la funzione di correlazione ha lunghezza {len(rho)}")
    #lag = np.arange(max_lag)
    plot1(
        datiX=lag,
        datiY=rho,
        titoloPrincipale=f"Average autocorrelations on many runs for T={T}",
        titoloX="k",
        titoloY=r"$\rho(k)$",
        titoloLegenda="Average autocorrelation func.",
        nome_output=f"try_autocorr_task1_L{L}_T{T}_{nmcs_eq}"
    )
    dati = np.column_stack((lag, rho))
    p0=(1.0, 0.0, 0.0)
    A_fit, B_fit, C_fit = fit_funzione(dati, f_esponenziale, p0)
    fit_rho = A_fit * np.array([f_esponenziale(x, B_fit) for x in lag]) + C_fit
    #B_fit, C_fit = fit_funzione(dati, f_esponenziale)
    #fit_rho = np.array([f_esponenziale(x, B_fit) for x in lag]) + C_fit
    plot2(
        datiX=lag,
        datiY1=rho,
        datiY2=fit_rho,
        titoloPrincipale=f"Average autocorrelations on many runs for T={T}",
        titoloX="k",
        titoloY=r"$\rho(k)$",
        titoloLegenda1="Average autocorrelation func.",
        titoloLegenda2=rf"autocorrelation fit $\tau={1/B_fit:.3f}$",
        nome_output=f"try_autocorr_task1_L{L}_T{T}_{nmcs_eq}_fit"
    )
    # calc_autocorrelation(
    #     E_history=energy_hist,
    #     L=L,
    #     T=T,
    #     nmcs_eq=nmcs_eq,
    #     max_lag = int((nmcs-1)/4), #rumoroso
    #     nome_file=f"/home/emanuele/Magistrale/LAB_COMP_I/Ising_model/task5/rhoTask1_L{L}_T{T}_step{nmcs_eq}-{nmcs}.txt"
    # )
    #snapshot(final_lattice, T, L, nome_output=f"ising_finalSnapshot_L{L}_T{T}_J{J}")

def main():
    # Parametri
    #L = 30 #numero di spin sul lato
    #Aumentare il numero di spin attenua le oscillazioni della magnetizzazione
    #totale dovute alla temperatura che incentiva i flip a energia sfavorita.
    #T = 2.0 #temperatura
    #J = 1.0 #energia di scambio
    #nmcs = 1000  # Numero totale di passi Monte Carlo per spin
    #La funzione metropolis_step esegue i flip casualmente, quindi se il numero nmcs
    #non è adeguato, alcuni spin potrebbero non essere mai capovolti.
    # stato=""
    # stato="provaDisp-1"
    # Esecuzione della simulazione
    #energy_hist, mag_hist, final_lattice = run_ising_simulation(L, T, J, nmcs)
    #steps = np.arange(1, nmcs + 1) #array all'aumentare degli step
    ising_art = r"""
     ___   ____    ___   _   _    ____
    |_ _| / ___|  |_ _| | \ | |  / ___|
     | |  \___ \   | |  |  \| | | |  _
     | |   ___) |  | |  | |\  | | |_| |
    |___| |____/  |___| |_| \_|  \____|
    """
    print(ising_art)
    print("Credits to: Emanuele Puglisi")
    print("")
    #energy_mag_vs_step(L, J, nmcs, T, nmcs_eq, video, viridis, ordered, obc)
    energy_mag_vs_step(
        L=30,
        J=1.0,
        nmcs=900000,
        T=2.0,
        nmcs_eq=180000, #attento a scegliere i multipli giusti del 900 (unbounded loop)
        video=False,
        viridis=False,
        ordered=False,
        obc=False,
        n_seeds=30,
        max_lag=21*900
    )
    # energy_mag_vs_step(
    #     L=30,
    #     J=1.0,
    #     nmcs=900000,
    #     T=2.0,
    #     nmcs_eq=180000, #attento a scegliere i multipli giusti del 900 (unbounded loop)
    #     video=False,
    #     viridis=False,
    #     ordered=True,
    #     obc=False,
    #     n_seeds=5
    # )

    # energy_mag_vs_T(
    #     L=30,
    #     J=1.0,
    #     nmcs=900000,
    #     T_i = 1, #1.0
    #     T_f = 4, #4.0
    #     delta_T = 0.05,
    #     nmcs_eq = 180000,
    #     video=False,
    #     viridis=False,
    #     ordered=False,
    #     obc=False,
    #     n_seeds=30
    # )

if __name__ == "__main__":
    main()