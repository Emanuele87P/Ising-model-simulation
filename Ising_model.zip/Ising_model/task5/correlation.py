import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import colormaps as cmaps
import time
import cv2
import os
import glob
from scipy import constants
from functools import wraps
from numba import njit
from matplotlib.font_manager import FontProperties
from matplotlib.patches import Patch
from matplotlib.colors import ListedColormap



# >> WRAPPERS

def timeit(func):
    @wraps(func)
    #args e kwargs permettono a una funzione "wrapper" di accettare qualsiasi tipo di input senza sapere in anticipo quanti 
    #o quali parametri riceverà la funzione originale
    def _func(*args, **kwargs):
        ti = time.time()
        res = func(*args, **kwargs)
        tf = time.time()
        dt = tf - ti
        print(f"Wall time: {dt:.6f} s")
        return res
    return _func

def separa_stampa(func):
    @wraps(func)
    def _wrapper(*args, **kwargs):
        print("\n" + "="*60)
        #print(f">>> ESECUZIONE: {func.__name__}")
        print("="*60)
        res = func(*args, **kwargs)
        print("-"*60 + "\n")
        return res
    return _wrapper

# >> GRAPHS

def plot1(datiX, datiY, titoloPrincipale, titoloX, titoloY,
         titoloLegenda, nome_output):

    # FONT
    times_font = FontProperties(family='Times New Roman', style='normal')
    times_dict = {'fontname': 'Times New Roman'}

    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif']
    plt.rcParams['mathtext.fontset'] = 'stix'

    # CREAZIONE FIGURA
    fig, ax = plt.subplots(figsize=(7, 5), dpi=300)

    # GRAFICO
    ax.plot(
        datiX,
        datiY,
        color="#B22222",
        alpha=0.8,
        linewidth=0.8,
        label=titoloLegenda
    )

    # TITOLI
    ax.set_xlabel(titoloX, fontsize=16, labelpad=8)
    ax.set_ylabel(titoloY, fontsize=16, labelpad=8)

    ax.text(
        0.5, 0.95, titoloPrincipale,
        transform=ax.transAxes,
        fontsize=13,
        verticalalignment='top',
        horizontalalignment='center'
    )

    # LIMITI DINAMICI
    ymin, ymax = np.min(datiY), np.max(datiY)
    yrange = ymax - ymin

    if yrange == 0:
        yrange = max(abs(ymin), 1.0)

    xrange = np.max(datiX) - np.min(datiX)

    if xrange == 0:
        xrange = max(abs(np.min(datiX)), 1.0)

    ax.set_ylim(
        ymin - 0.05 * yrange,
        ymax + 0.35 * yrange
    )

    ax.set_xlim(
        np.min(datiX) - 0.02 * xrange,
        np.max(datiX) + 0.02 * xrange
    )

    # LEGENDA
    ax.legend(
        frameon=False,
        fontsize=11,
        loc='upper center',
        bbox_to_anchor=(0.7, 0.88)
    )

    # TICK
    ax.xaxis.set_major_locator(ticker.MaxNLocator(nbins=7))
    ax.yaxis.set_major_locator(ticker.MaxNLocator(nbins=7))

    ax.tick_params(
        axis='both',
        which='major',
        labelsize=12,
        direction='in',
        top=False,
        right=False
    )

    # FONT DEI TICK
    fig.canvas.draw()

    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontfamily('serif')
        label.set_fontname('STIXGeneral')

    # SALVATAGGIO
    plt.tight_layout()

    plt.savefig(
        f'{nome_output}.jpg',
        format='jpeg',
        dpi=300
    )

    plt.close(fig)

def plot2(datiX, datiY1, datiY2, titoloPrincipale, titoloX, titoloY, titoloLegenda1, titoloLegenda2, nome_output):
    # FONT
    # Definizione esplicita delle proprietà del font Times New Roman
    times_font = FontProperties(family='Times New Roman', style='normal')
    times_dict = {'fontname': 'Times New Roman'}
    # Configurazione globale di backup
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif']
    plt.rcParams['mathtext.fontset'] = 'stix'
    # Mantiene lo stile Times anche per formule matematiche

    # print("Y1 min:", np.min(datiY1))
    # print("Y1 max:", np.max(datiY1))
    # #print("Y1 primi valori:", datiY1[:10])
    # print("Y2 min:", np.min(datiY2))
    # print("Y2 max:", np.max(datiY2))

    # Creazione della figura fig con dimensioni (width, height), ax sono gli assi
    fig, ax = plt.subplots(figsize=(7, 5), dpi=300)

    # SCATTERPLOT
    # Grafico a dispersione con punti adattati allo stile dell'istogramma. s è un parametro di size
    ax.plot(datiX, datiY1, color="#B22222", alpha=0.8, linewidth=0.8, label=titoloLegenda1)
    #ax.scatter(datiX, datiY1, color="#B22222", alpha=0.8, edgecolors="#B22222", linewidths=0.0, s=3, label=titoloLegenda1)

    # SCATTERPLOT 2 (Seconda serie di dati aggiunta, es. Energia Potenziale)
    ax.plot(datiX, datiY2, color="#00416D", alpha=0.8, linewidth=0.8, label=titoloLegenda2)
    #ax.scatter(datiX, datiY2, color="#00416D", alpha=0.8, edgecolors="#00416D", linewidths=0.0, s=3, label=titoloLegenda2)

    # TITOLI
    # Etichette degli assi e titolo interno
    ax.set_xlabel(titoloX, fontsize=16, labelpad=8)
    ax.set_ylabel(titoloY, fontsize=16, labelpad=8)
    # Posizione del titolo (centrato in alto)
    ax.text(0.5, 0.95, titoloPrincipale, 
            transform=ax.transAxes, fontsize=13,
            verticalalignment='top', horizontalalignment='center')
    # Aumenta il limite Y massimo del 25% per creare spazio bianco in alto ( *1.25)
    # interval_max = max(ax.get_ylim()[1], ax.get_xlim()[1])
    # interval_min = min(ax.get_ylim()[0], ax.get_xlim()[0])
    # ax.set_ylim(interval_min, interval_max * 1.25)
    # ax.set_xlim(interval_min, interval_max * 1.25)
    # #stessa scala
    # ax.set_aspect('equal', adjustable='box') 

    #AGGIUNTA DINAMICA
    all_y = np.concatenate([datiY1, datiY2])
    ymin, ymax = np.min(all_y), np.max(all_y)
    yrange = ymax - ymin
    # Crea dinamicamente uno spazio bianco extra in alto (~35%) per titolo e legenda
    ax.set_ylim(ymin - 0.05 * yrange, ymax + 0.35 * yrange)
    ax.set_xlim(np.min(datiX) - 0.02 * (np.max(datiX) - np.min(datiX)), 
                np.max(datiX) + 0.02 * (np.max(datiX) - np.min(datiX)))

    # LEGENDA
    # Impostazione della legenda (senza bordo/frame e centrata sotto il titolo)
    #ax.legend(frameon=False, fontsize=11, loc='upper center', bbox_to_anchor=(0.5, 0.88))
    ax.legend(frameon=False, fontsize=11, loc='upper center', bbox_to_anchor=(0.7, 0.88))

    # TICK
    # Gestione dei tick (max 6 punti per asse, tacche rivolte all'interno)
    ax.xaxis.set_major_locator(ticker.MaxNLocator(nbins=7))
    ax.yaxis.set_major_locator(ticker.MaxNLocator(nbins=7))
    # RIMOZIONE tick in alto e a destra (top=False, right=False)
    ax.tick_params(axis='both', which='major', labelsize=12, direction='in', top=False, right=False)
    # Forzatura del font sui numeri degli assi (tick labels)
    fig.canvas.draw()  # Genera i tick prima di modificarne le proprietà
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontfamily('serif')
        label.set_fontname('STIXGeneral')

    # SALVATAGGIO
    # Layout e salvataggio
    plt.tight_layout()
    # Salvataggio in formato JPEG e risoluzione
    plt.savefig(f'{nome_output}.jpg', format='jpeg', dpi=300)
    #plt.show()
    plt.close(fig)

def plot2error(datiX, datiY1, datiY2,
         titoloPrincipale, titoloX, titoloY,
         titoloLegenda1, titoloLegenda2,
         nome_output,
         erroriY1=None, erroriY2=None):

    # FONT
    times_font = FontProperties(family='Times New Roman', style='normal')

    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif']
    plt.rcParams['mathtext.fontset'] = 'stix'

    fig, ax = plt.subplots(figsize=(7, 5), dpi=300)

    # CONTROLLO BARRE DI ERRORE
    for nome, errore, dati in [
        ("erroriY1", erroriY1, datiY1),
        ("erroriY2", erroriY2, datiY2)
    ]:
        if errore is not None:
            errore = np.asarray(errore, dtype=float)

            if errore.shape != np.asarray(dati).shape:
                raise ValueError(f"{nome} deve avere la stessa lunghezza dei dati!")

            if not np.all(np.isfinite(errore)) or np.any(errore < 0):
                raise ValueError(f"{nome} deve contenere valori finiti e non negativi!")

    # PRIMA SERIE
    ax.errorbar(
        datiX, datiY1,
        yerr=erroriY1,
        color="#B22222",
        alpha=0.8,
        linewidth=0.8,
        elinewidth=0.8,
        capsize=2,
        label=titoloLegenda1
    )

    # SECONDA SERIE
    ax.errorbar(
        datiX, datiY2,
        yerr=erroriY2,
        color="#00416D",
        alpha=0.8,
        linewidth=0.8,
        elinewidth=0.8,
        capsize=2,
        label=titoloLegenda2
    )

    # TITOLI
    ax.set_xlabel(titoloX, fontsize=16, labelpad=8)
    ax.set_ylabel(titoloY, fontsize=16, labelpad=8)

    ax.text(
        0.5, 0.95, titoloPrincipale,
        transform=ax.transAxes,
        fontsize=13,
        verticalalignment='top',
        horizontalalignment='center'
    )

    # LIMITI DINAMICI
    all_y = np.concatenate([datiY1, datiY2])

    ymin, ymax = np.min(all_y), np.max(all_y)
    yrange = ymax - ymin

    ax.set_ylim(
        ymin - 0.05 * yrange,
        ymax + 0.35 * yrange
    )

    ax.set_xlim(
        np.min(datiX) - 0.02 * (np.max(datiX) - np.min(datiX)),
        np.max(datiX) + 0.02 * (np.max(datiX) - np.min(datiX))
    )

    # LEGENDA
    ax.legend(
        frameon=False,
        fontsize=11,
        loc='upper center',
        bbox_to_anchor=(0.7, 0.88)
    )

    # TICK
    ax.xaxis.set_major_locator(ticker.MaxNLocator(nbins=7))
    ax.yaxis.set_major_locator(ticker.MaxNLocator(nbins=7))

    ax.tick_params(
        axis='both',
        which='major',
        labelsize=12,
        direction='in',
        top=False,
        right=False
    )

    fig.canvas.draw()

    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontfamily('serif')
        label.set_fontname('STIXGeneral')

    # SALVATAGGIO
    plt.tight_layout()

    plt.savefig(
        f'{nome_output}.jpg',
        format='jpeg',
        dpi=300
    )

    plt.close(fig)

def carica_file_prefisso(prefisso, suffisso=".txt"):
    pattern = f"{prefisso}*{suffisso}"
    matches = sorted(glob.glob(pattern))

    if not matches:
        raise FileNotFoundError(f"Nessun file trovato con pattern: {pattern}")

    if len(matches) > 1:
        print(f"Attenzione: trovati più file per '{pattern}', uso: {matches[0]}")

    return np.loadtxt(matches[0])

def main():
    L=30
    T=2.0
    J=1.0

    # data1 = np.loadtxt(f"rhoTask1_L{L}_T{T}*.txt")
    # data4 = np.loadtxt(f"rhoTask4_L{L}_T{T}*.txt")

    # Nel tuo main():
    data1 = carica_file_prefisso(f"rhoTask1_L{L}_T{T}")
    data4 = carica_file_prefisso(f"rhoTask4_L{L}_T{T}")

    k1 = data1[:, 0]
    rho1 = data1[:, 1]
    k4 = data4[:, 0]
    rho4 = data4[:, 1]

    # print(f"t_MCS_corr {t_MCS_corr}")
    # print(f"t_MCS_lessCorr {t_MCS_lessCorr}")


    # # Genera 502 indici equidistanti tra il primo (0) e l'ultimo elemento
    # indici = np.linspace(0, len(t_MCS_corr) - 1, 501, dtype=int)
    # # Se t_MCS_corr è un array NumPy:
    # t_MCS_corr_ridotto = t_MCS_corr[indici]
    # # Se t_MCS_corr è una lista standard di Python:
    # # t_MCS_corr_ridotto = [t_MCS_corr[i] for i in indici]

    print(f"len(k1)={len(k1)}, len(k4)={len(k4)}")
    print("\n")
    print(rho1)
    print("\n")
    #indici = np.linspace(0, len(k1) - 1, len(k4), dtype=int)
    indici = np.arange(len(k4)) * (L * L)   # 0, 900, 1800, 2700, ...
    #k1 = k1[indici]
    rho1 = rho1[indici]
    #print(f"len(k1)={len(k1)}, len(k4)={len(k4)}")

    print(rho1)
    print("\n")
    print(rho4)

    # rho1 = np.interp(k4, k1, rho1)
    # k1 = k4

    plot2(
        datiX=k4, 
        datiY1=rho1, 
        datiY2=rho4, 
        titoloPrincipale="Autocorrelation functions at T=2.0", 
        titoloX="lag", 
        titoloY="values", 
        titoloLegenda1="1 MC step = 1 flip", 
        titoloLegenda2="1 MC = 1 sweep", 
        nome_output=f"LessCORRcorrelation_L{L}_T{T}_J{J}"
    )
    
    # if len(k1)==len(k4):
    #     plot2(
    #         datiX=k4, 
    #         datiY1=rho1, 
    #         datiY2=rho4, 
    #         titoloPrincipale="Autocorrelation functions at T=2.0", 
    #         titoloX="lag", 
    #         titoloY="values", 
    #         titoloLegenda1="First task code", 
    #         titoloLegenda2="Fourth task code", 
    #         nome_output=f"LessCORRcorrelation_L{L}_T{T}_J{J}"
    #     )
    # else:
    #     print(f"Non posso stampare il grafico! len(k1)={len(k1)}, len(k4)={len(k4)}")

    # plot1(
    #     datiX=t_MCS_lessCorr_ridotto, 
    #     datiY=rho_lessCorr, 
    #     titoloPrincipale="Autocorrelation functions at T=2.0", 
    #     titoloX="MSC time", 
    #     titoloY="values", 
    #     titoloLegenda="Forth task code", 
    #     nome_output=f"LessCORRcorrelation_L{L}_T{T}_J{J}"
    # )

    # plot1(
    #     datiX=t_MCS_corr, 
    #     datiY=rho_corr, 
    #     titoloPrincipale="Autocorrelation functions at T=2.0", 
    #     titoloX="MSC time", 
    #     titoloY="values", 
    #     titoloLegenda="First task code", 
    #     nome_output=f"MoreCORRcorrelation_L{L}_T{T}_J{J}"
    # )

if __name__ == "__main__":
    main()



